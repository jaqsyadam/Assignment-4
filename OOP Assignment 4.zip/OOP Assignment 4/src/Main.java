import java.util.Scanner;

interface TravelStrategy {
    void travel();
}

class WalkStrategy implements TravelStrategy {
    @Override
    public void travel() {
        System.out.println("Способ передвижения выбран: Пешком");
        System.out.println("Стоимость: 0 тенге");
        System.out.println("");
        System.out.println("");
    }
}

class BusStrategy implements TravelStrategy {
    @Override
    public void travel() {
        System.out.println("Способ передвижения выбран: На автобусе");
        System.out.println("Стоимость: 90 тенге");
        System.out.println("");
        System.out.println("");
    }
}

class TaxiStrategy implements TravelStrategy {
    @Override
    public void travel() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Способ передвижения выбран: На такси");
        System.out.print("Введите километраж: ");
        double kilometers = scanner.nextDouble();
        double cost = kilometers * 150;
        System.out.println("Итоговая стоимость: " + cost + " тенге");
        System.out.println("");
        System.out.println("");
    }
}

class TravelContext {
    private TravelStrategy travelStrategy;

    public void setTravelStrategy(TravelStrategy travelStrategy) {
        this.travelStrategy = travelStrategy;
    }

    public void executeTravel() {
        travelStrategy.travel();
    }
}

public class Main {
    public static void main(String[] args) {
        TravelContext context = new TravelContext();
        while(true){
            Scanner scanner = new Scanner(System.in);

            System.out.println("Выберите способ передвижения:");
            System.out.println("1. Пешком");
            System.out.println("2. На автобусе");
            System.out.println("3. На такси");
            System.out.println("4. Выйти");

            int choice = scanner.nextInt();

            if(choice == 1) {
                context.setTravelStrategy(new WalkStrategy());
            } else if(choice == 2) {
                context.setTravelStrategy(new BusStrategy());
            } else if(choice == 3) {
                context.setTravelStrategy(new TaxiStrategy());
            } else if(choice == 4){
                System.exit(0);
            } else {
                System.out.println("Неизвестная команда");
            }
            context.executeTravel();
        }
    }
}
